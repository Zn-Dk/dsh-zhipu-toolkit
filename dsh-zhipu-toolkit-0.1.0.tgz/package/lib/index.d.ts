/**
 * Dual-endpoint Zhipu BigModel GLM provider routes backed by pi-ai message
 * conversion: the Coding Plan endpoint (`zai`) and the ordinary OpenAPI
 * endpoint (`zhipu`). One is served at a time (they expose the same models
 * and semantics; the choice is which billing channel the account uses),
 * each with its own label and credential reference.
 *
 * Configuration is hot-reloadable: the plugin owns the `zhipu-toolkit`
 * settings namespace (`settings.installSection`), so edits made in the
 * settings card — or directly in settings.yaml — re-resolve the routes
 * without a restart. The Client half reaches the same namespace over the
 * `/zhipu-toolkit-settings` connection RPC channel (see ./settings-rpc.ts).
 *
 * @module dsh-zhipu-toolkit
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config, type Config as ConfigType } from './config.ts';
export declare const name = "dsh-zhipu-toolkit";
export declare const inject: string[];
export { Config };
export type { Config as ConfigType } from './config.ts';
export { appendMissing, CODING_BASE_URL, CODING_PROVIDER_ID, DIRECTLY_VERIFIED, discoverModels, GLM53_THINKING_LEVEL_MAP, GLM_COMPAT, maintainedModels, MAINTAINED_TEXT_MODELS, PAAS_BASE_URL, PAAS_PROVIDER_ID, parseModelIds, textModel, } from './catalog.ts';
export { LOCAL_API_KEY_REF, resolveConfig, } from './config.ts';
export type { Endpoints, ReasoningTier, ResolvedConfig as ResolvedConfigType, ResolvedEndpoint, } from './config.ts';
export { REASONING_TIERS } from './config.ts';
export { createSettingsRpcHandler, MUTABLE_FIELDS } from './settings-rpc.ts';
export type { RpcResult, SettingsPathOp, SettingsProviderFace, SettingsView } from './settings-rpc.ts';
/** Settings namespace owned by this plugin (lowercase kebab-case). */
export declare const SETTINGS_NAMESPACE = "zhipu-toolkit";
/** Connection RPC channel serving the settings card (see CHANNEL_PATTERN: no inner slashes). */
export declare const SETTINGS_CHANNEL = "/zhipu-toolkit-settings";
/** The default reasoning tier applied to effort-undefined requests. */
export declare const DEFAULT_REASONING_TIER: "low";
/**
 * Register and live-filter the BigModel provider route.
 *
 * The composition entry (`rawConfig` from cordis.patch.yml) is the fallback
 * source; once the settings service is present the `zhipu-toolkit` namespace
 * section takes over as the authoritative source and committed edits re-run
 * {@link resync} without a restart.
 * @param ctx - Cordis context providing LLM and credential services.
 * @param rawConfig - validated plugin configuration (composition entry).
 */
export declare function apply(ctx: Context, rawConfig: ConfigType): void;
