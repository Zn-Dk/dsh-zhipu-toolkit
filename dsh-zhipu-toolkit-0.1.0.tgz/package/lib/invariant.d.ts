/**
 * Package-owned invariant companion for dsh-zhipu-toolkit.
 *
 * Unlike dsh-bigmodel-catalog (whose invariant companion is a no-op because
 * the LLM registry owns everything), this package owns verifiable catalog
 * invariants that hold regardless of registration lifecycle: the wire-tier
 * whitelist the API accepts, and the thinking-level mapping that must keep
 * routing every offered picker tier into it.
 *
 * @module dsh-zhipu-toolkit/invariant
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "dsh-zhipu-toolkit-invariant";
export declare const inject: string[];
/** The only reasoning-effort wire values the BigModel API accepts (verified 2026-09-06). */
export declare const WIRE_TIER_WHITELIST: Set<string>;
/** Picker tiers that survive mapping — every key mapped to `null` is hidden instead. */
export declare const OFFERED_PICKER_TIERS: readonly ("high" | "max" | "off" | "minimal" | "low" | "medium" | "xhigh")[];
/** The complete GLM-5.3-series wire mapping as a plain object, for tests. */
export declare const GLM53_WIRE_MAP: Readonly<Record<string, string>>;
export declare const apply: (ctx: Context) => Promise<() => void>;
