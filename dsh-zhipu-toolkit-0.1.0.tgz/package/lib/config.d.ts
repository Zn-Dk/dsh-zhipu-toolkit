/**
 * Configuration schema and validation for dsh-zhipu-toolkit.
 *
 * One schema answers three layers: the schemastery shape rendered by
 * configuration surfaces, the validator refusing unserviceable values where
 * they are written, and the resolved form the plugin assembles per endpoint.
 *
 * @module dsh-zhipu-toolkit/config
 */
import z from '@deepseek-ai/schemastery';
/**
 * Which BigModel endpoint this deployment serves. The two endpoints expose
 * the same models and the same request semantics (verified live 2026-09-06:
 * identical `/models` lists, identical thinking/reasoning_effort behavior);
 * they differ only in billing — the Coding Plan endpoint is the
 * subscription-backed channel (Lite/Pro/Max quota, scoped to official coding
 * tools), the ordinary endpoint bills per token. A deployment picks the one
 * its account is billed on, so the field is one-of-two, not both.
 */
export type Endpoints = 'coding' | 'paas';
/**
 * Reasoning-effort tier wired for effort-undefined requests. GLM-5.3-series
 * models always think (`thinking:disabled` is refused with error 1210), so
 * the default stays on the cheapest offered tier; higher tiers trade latency
 * for depth on every request that does not name an effort itself.
 */
export type ReasoningTier = 'low' | 'medium' | 'high' | 'xhigh' | 'max';
/** Default credential references, one per endpoint. */
export declare const DEFAULT_CODING_API_KEY_ENV = "BIGMODEL_API_KEY";
export declare const DEFAULT_PAAS_API_KEY_ENV = "ZHIPU_API_KEY";
/**
 * Credential reference holding the locally-managed API key when
 * {@link Config.useLocalApiKey} is on. The value lives in the dsh credentials
 * store (written through the settings card), never in settings.yaml.
 */
export declare const LOCAL_API_KEY_REF = "ZHIPU_TOOLKIT_API_KEY";
/** Reasoning tiers offered by every maintained GLM model, cheapest first. */
export declare const REASONING_TIERS: readonly ReasoningTier[];
/** Plugin configuration validated by {@link Config}. */
export interface Config {
    /**
     * The single BigModel endpoint this deployment serves: `coding` (Coding
     * Plan, subscription quota) or `paas` (ordinary API, per-token billing).
     */
    endpoints?: Endpoints;
    /** Credential reference resolved for every coding-endpoint request. */
    codingApiKeyEnv?: string;
    /** Credential reference resolved for every ordinary-endpoint request. */
    paasApiKeyEnv?: string;
    /** BigModel Coding Plan API base URL. */
    codingBaseURL?: string;
    /** Ordinary BigModel OpenAPI base URL. */
    paasBaseURL?: string;
    /** Provider label shown in model selectors for the served route. */
    displayName?: string;
    /**
     * Reasoning tier wired for requests that name no effort themselves.
     * GLM-5.3-series models cannot turn thinking off, so `off` is not offered.
     */
    defaultReasoningTier?: ReasoningTier;
    /**
     * Hold the API key locally: when on, the plugin resolves the key from the
     * `ZHIPU_TOOLKIT_API_KEY` credential reference (written by the settings
     * card through the credentials service) instead of the per-endpoint env
     * reference; the env path stays as fallback when the local key is absent.
     */
    useLocalApiKey?: boolean;
    /** Maximum provider idle time while one stream read is outstanding. */
    streamIdleTimeoutMs?: number;
    /**
     * Base64 image payload bound for one request. Older images become text
     * placeholders once a session's accumulated images exceed it, so a long
     * session keeps completing requests instead of being refused for size.
     */
    maxRequestImageBytes?: number;
    /** Total-pixel budget for each deterministic inline request version. */
    requestImagePixelBudget?: number;
    /** Raw encoded-byte cap for each deterministic inline request version. */
    requestImageMaxBytes?: number;
}
/** Schemastery validator for the plugin configuration. */
export declare const Config: z<Config>;
/** One endpoint route after defaults and validation. */
export interface ResolvedEndpoint {
    /** Harness route id, also the profile key in the adapter. */
    readonly provider: 'zai' | 'zhipu';
    /** Credential reference resolved for every request on this route. */
    readonly apiKeyEnv: string;
    /** API base URL with no trailing slash. */
    readonly baseURL: string;
    /** Provider label shown in model selectors for this route. */
    readonly displayName: string;
}
/** Fully resolved plugin configuration. */
export interface ResolvedConfig {
    /** The single route to register. */
    readonly endpoints: readonly ResolvedEndpoint[];
    /** Reasoning tier wired for effort-undefined requests. */
    readonly defaultReasoningTier: ReasoningTier;
    /** Whether the locally-managed API key reference takes precedence. */
    readonly useLocalApiKey: boolean;
    readonly streamIdleTimeoutMs: number;
    readonly maxRequestImageBytes: number;
    readonly requestImagePixelBudget: number;
    readonly requestImageMaxBytes: number;
}
/**
 * Validate a raw configuration and resolve every default.
 * @param config - schema-validated plugin configuration.
 * @returns the resolved route and shared settings.
 * @throws Error naming the first unserviceable entry.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
