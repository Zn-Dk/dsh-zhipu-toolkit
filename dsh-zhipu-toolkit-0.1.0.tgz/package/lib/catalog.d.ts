/**
 * Self-maintained GLM family model catalog for Zhipu BigModel endpoints.
 *
 * Pure logic, no I/O: the descriptor table, the verified thinking-level map,
 * the wire-compatibility flags, the merge policy over pi-ai's builtin catalog,
 * and the `/models` payload parsing live here so tests can pin every shape.
 *
 * The semantics inherited from dsh-bigmodel-catalog commit d8189e3
 * (verified live 2026-09-06 against both BigModel endpoints):
 * - `compat.supportsReasoningEffort: true` + `compat.maxTokensField: 'max_tokens'`
 * - GLM-5.3-series `thinkingLevelMap`: `off`/`minimal` removed (`null`),
 *   `low`/`medium`/`high` collapse onto the `high` wire tier, `xhigh`/`max`
 *   unlock `max`.
 * - profile default reasoning tier `low`, so effort-undefined requests never
 *   wire `thinking: {type: "disabled"}` (the API refuses it with error 1210).
 * - descriptors carrying an explicit thinking-level map supersede the builtin
 *   catalog's stale entry for the same id.
 *
 * @module dsh-zhipu-toolkit/catalog
 */
import type { Api, Model, OpenAICompletionsCompat } from '@earendil-works/pi-ai';
/** pi-ai provider id served by the BigModel Coding Plan endpoint. */
export declare const CODING_PROVIDER_ID = "zai";
/** Harness route id served by the ordinary BigModel OpenAPI endpoint. */
export declare const PAAS_PROVIDER_ID = "zhipu";
/** BigModel Coding Plan API base URL. */
export declare const CODING_BASE_URL = "https://open.bigmodel.cn/api/coding/paas/v4";
/** Ordinary BigModel OpenAPI base URL. */
export declare const PAAS_BASE_URL = "https://open.bigmodel.cn/api/paas/v4";
/** Wire-compatibility flags verified against both BigModel endpoints. */
export declare const GLM_COMPAT: OpenAICompletionsCompat;
/**
 * GLM-5.3-series models always think: the API refuses `thinking:disabled` and
 * `reasoning_effort:minimal/medium` outright (verified 2026-09-06 against the
 * coding endpoint, error 1210 "请使用 low、high 或 max"). `off` is removed from
 * the picker entirely; the surviving low tiers collapse onto `high` (upstream's
 * glm-5.2 strategy), and xhigh/max unlock the `max` wire tier.
 */
export declare const GLM53_THINKING_LEVEL_MAP: {
    readonly off: null;
    readonly minimal: null;
    readonly low: "high";
    readonly medium: "high";
    readonly high: "high";
    readonly xhigh: "max";
    readonly max: "max";
};
/** One self-maintained text model descriptor. */
export interface MaintainedTextModel {
    readonly id: string;
    readonly name: string;
    readonly contextWindow: number;
    readonly maxTokens: number;
    readonly thinkingLevelMap?: Model<'openai-completions'>['thinkingLevelMap'];
}
/** The full GLM chat family this toolkit maintains, newest last. */
export declare const MAINTAINED_TEXT_MODELS: readonly MaintainedTextModel[];
/** Build one openai-completions model descriptor bound to a BigModel endpoint. */
export declare function textModel(id: string, name: string, contextWindow: number, maxTokens: number, thinkingLevelMap?: Model<'openai-completions'>['thinkingLevelMap']): Model<'openai-completions'>;
/**
 * Merge additions over a base catalog. An addition carrying an explicit
 * thinking level map (and the compat flags verified against the live API)
 * supersedes the base's older entry for the same id, so the map actually
 * reaches the wire; a map-less addition only fills ids the base lacks.
 * @param base - catalog entries, typically pi-ai's builtin models.
 * @param additions - self-maintained descriptors to overlay.
 * @returns merged descriptors in base order followed by new additions.
 */
export declare function appendMissing(base: readonly Model<Api>[], additions: readonly Model<Api>[]): readonly Model<Api>[];
/** Maintained descriptors plus models live-verified ahead of pi-ai's catalog. */
export declare const maintainedModels: readonly Model<Api>[];
/** Models proven by a direct completion may remain even when `/models` lags. */
export declare const DIRECTLY_VERIFIED: Set<string>;
/**
 * Parse the provider-neutral ids returned by BigModel's Models endpoint.
 * @param payload - decoded JSON response body.
 * @returns model ids in provider order.
 * @throws Error when the payload is not `{ data: [{ id: string }, ...] }`.
 */
export declare function parseModelIds(payload: unknown): string[];
/**
 * Reconcile a live `/models` list with the maintained catalog, keeping
 * directly-verified additions even when the endpoint lags.
 * @param payload - decoded provider response body.
 * @returns maintained descriptors currently reported or directly verified.
 */
export declare function discoverModels(payload: unknown): readonly Model<Api>[];
