/**
 * Settings RPC bridge for the Client half of dsh-zhipu-toolkit.
 *
 * Pure factory, unit-testable without a real DSH host: it wraps the host
 * settings provider (the same seam the official settings surfaces use) into
 * the get/mutate endpoint pair the settings card calls over
 * `connection.rpc`, plus a local-API-key endpoint set backed by the
 * credentials service so the card can hold the key in the credentials store
 * (never in settings.yaml). The field whitelist below is the whole attack
 * surface of the channel — a client can only write fields the card itself
 * owns.
 *
 * Provider faces consumed (see @deepseek-ai/dsh-settings and
 * @deepseek-ai/dsh-credentials):
 *   settings.get(ns) -> resolved value, or undefined while unregistered
 *   settings.mutate(ns, ops, expectedRevision?) -> Promise<void>
 *   settings.writable -> boolean
 *   settings.describe({redactSecrets: true}) -> descriptors with revisions
 *   credentials.set(ref, value) -> Promise<void>
 *   credentials.unset(ref) -> Promise<void>
 *   credentials.describe(ref) -> Promise<{configured, writable, ...}>
 *
 * @module dsh-zhipu-toolkit/settings-rpc
 */
/** Which card-editable fields the mutate endpoint may write. */
export declare const MUTABLE_FIELDS: readonly ["endpoints", "codingApiKeyEnv", "paasApiKeyEnv", "codingBaseURL", "paasBaseURL", "displayName", "defaultReasoningTier", "useLocalApiKey"];
/** Connection RPC result envelope (wire shape of @deepseek-ai/dsh-client-connection). */
export type RpcResult = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
};
/** One path-addressed edit over the namespace's user section. */
export interface SettingsPathOp {
    readonly op: 'set' | 'unset';
    readonly path: readonly string[];
    readonly value?: unknown;
}
/** Snapshot the card reads after every get/mutate. */
export interface SettingsView {
    /** Current resolved section. */
    readonly value: unknown;
    /** Monotonic revision of the raw user section; send back as expectedRevision. */
    readonly revision: number;
}
/** Local-API-key state the card reads; the value itself never crosses. */
export interface LocalApiKeyView {
    /** Whether the local key reference currently resolves. */
    readonly configured: boolean;
    /** Whether the credentials provider can write this reference. */
    readonly writable: boolean;
    /** Masked summary of the saved value (bullets + last characters). */
    readonly masked: string;
}
/** Provider face this bridge needs from the settings service. */
export interface SettingsProviderFace {
    get(ns: string): unknown;
    mutate(ns: string, ops: readonly SettingsPathOp[], expectedRevision?: number): Promise<void>;
    readonly writable: boolean;
    describe(options?: {
        redactSecrets?: boolean;
    }): ReadonlyArray<{
        ns: string;
        value: unknown;
        revision: number;
    }>;
}
/** Provider face this bridge needs from the credentials service. */
export interface CredentialsFace {
    set(ref: string, value: string): Promise<void>;
    unset(ref: string): Promise<void>;
    describe(ref: string): Promise<{
        configured: boolean;
        writable: boolean;
    }>;
    /**
     * Read the stored value and return a masked summary (bullets plus the
     * last characters), or `undefined` while unconfigured. The raw value
     * never crosses this seam; only the masked form does.
     */
    masked(ref: string): Promise<string | undefined>;
}
/**
 * Build the get/mutate/local-key endpoint handler for
 * `'/zhipu-toolkit-settings'`.
 *
 * The credentials face is addressed by reference *name*: the bridge passes
 * the `localKeyRef` it was constructed with (the plugin's
 * `ZHIPU_TOOLKIT_API_KEY`), so the factory stays pure while the wired host
 * handler reaches the real credentials service under exactly that name.
 *
 * @param settings - the host settings provider.
 * @param namespace - the `zhipu-toolkit` settings namespace.
 * @param credentials - the host credentials provider (local-key endpoints;
 *   a deployment without one can pass a stub rejecting every call).
 * @param localKeyRef - the credential reference the local key is stored
 *   under (default `ZHIPU_TOOLKIT_API_KEY`).
 * @returns async `(endpoint, payload) => RpcResult`.
 */
export declare function createSettingsRpcHandler(settings: SettingsProviderFace, namespace: string, credentials?: CredentialsFace, localKeyRef?: string): (endpoint: string, payload: unknown) => Promise<RpcResult>;
