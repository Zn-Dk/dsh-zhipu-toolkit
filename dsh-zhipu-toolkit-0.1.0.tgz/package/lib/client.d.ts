/**
 * Client half of dsh-zhipu-toolkit: the settings card.
 *
 * This source compiles verbatim to lib/client.js, which DSH loads through
 * window.__ModuleLoader__.load — it is NOT a plain ES module at runtime, so:
 * - the only top-level statement is the ModuleLoader registration;
 * - every require lives inside the factory closure and stays within the
 *   7-word client seed whitelist (react, react/jsx-runtime, react-dom,
 *   react-dom/client, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots,
 *   @deepseek-ai/dsh-client-ui-primitives);
 * - types are structural and local; no type-only imports (tsc emits this
 *   file's body unchanged apart from stripping annotations).
 *
 * The card reads and writes the `zhipu-toolkit` settings namespace over the
 * `/zhipu-toolkit-settings` connection RPC channel registered by the Host
 * half (see src/settings-rpc.ts), and holds the local API key through the
 * same channel's set-local-key endpoints (stored in the credentials
 * service, never in settings.yaml).
 *
 * UI discipline (see reference/UI_COMPONENTS.md): controls come from
 * @deepseek-ai/dsh-client-ui-primitives — Input for text and password
 * fields, Button for actions and toggles, Icon* for glyphs. Enum pickers
 * use a native <select> under the official chevron icon (the primitives
 * catalog has no standalone Select atom; the host Models card itself uses
 * a native select). Only the card's layout CSS is authored here, and every
 * rule is taken from the host settings cards' compiled CSS (field: 12px/1.5
 * 500 secondary label, 6px gap; input: 32px tall, r8, border-l4, bg-layer-1,
 * 14px text — see packages/client/ui-settings-models ModelsSection.module.css
 * and the installed family cards' .field/.input rules).
 */
interface ReactModule {
    useState<T>(initial: T): [T, (next: T | ((prev: T) => T)) => void];
    useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
    useSyncExternalStore(subscribe: (onStoreChange: () => void) => () => void, getSnapshot: () => unknown, getServerSnapshot?: () => unknown): unknown;
    createElement: unknown;
}
interface JsxRuntimeModule {
    jsx: (type: unknown, props: unknown, key?: unknown) => unknown;
}
interface PrimitivesModule {
    Input: (props: Record<string, unknown>) => unknown;
    Button: (props: Record<string, unknown>) => unknown;
    IconCheckOutline16: (props: Record<string, unknown>) => unknown;
    IconChevronDownOutline14: (props: Record<string, unknown>) => unknown;
    IconEditOutline16: (props: Record<string, unknown>) => unknown;
    IconCloseOutline16: (props: Record<string, unknown>) => unknown;
}
interface LocaleService {
    register(ns: string, dicts: Record<string, Record<string, string>>): () => void;
    bind(ns: string): (key: string, params?: Record<string, unknown>) => string;
    subscribe(fn: () => void): () => void;
    getLocale(): {
        active: string;
    };
}
interface ConnectionHandle {
    rpc: {
        call(channel: string, endpoint: string, payload: unknown, signal?: AbortSignal): Promise<{
            ok: true;
            value: unknown;
        } | {
            ok: false;
            error: {
                code: string;
                message: string;
            };
        }>;
    };
}
interface ClientContext {
    effect(effect: () => (() => void) | void, label?: string): () => void;
    locale: LocaleService;
    connection: ConnectionHandle;
    slots: {
        inject(key: string, callback: () => (() => void) | void): () => void;
        register(options: Record<string, unknown>, component: unknown): () => void;
    };
}
/**
 * The ModuleLoader facade the web shell installs before any client bundle
 * runs (structural: no DOM lib needed — this file compiles under lib=es2023).
 */
interface ModuleLoaderFacade {
    load(definition: {
        id: string;
        factory: (require: (spec: string) => never) => unknown;
    }): void;
}
/** Browser DOM surface this bundle touches, accessed structurally. */
interface StyleTag {
    dataset: Record<string, string>;
    textContent: string;
}
interface DomLike {
    querySelector(selector: string): unknown;
    createElement(tag: 'style'): StyleTag;
    head: {
        appendChild(tag: StyleTag): unknown;
    };
}
declare function dom(): DomLike | undefined;
/** The browser's language list, when a navigator exists. */
declare function browserLanguage(): string;
declare const __moduleLoader: ModuleLoaderFacade;
